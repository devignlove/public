<!doctype html>
<html <?php language_attributes(); ?>>
<head>
  <meta charset="<?php bloginfo('charset'); ?>">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

<header id="site-header" class="site-header" role="banner">
  <div class="site-header__inner">
    <a class="brand" href="<?php echo esc_url(home_url('/')); ?>">
      <?php if (has_custom_logo()) {
        the_custom_logo();
      } else { ?>
        <span class="brand__text"><?php bloginfo('name'); ?></span>
      <?php } ?>
    </a>

    <nav id="site-nav" class="site-nav" role="navigation" aria-label="<?php esc_attr_e('Menu principal','ozitheme'); ?>">
      <?php
      wp_nav_menu([
        'theme_location' => 'primary',
        'container'      => false,
        'menu_class'     => 'menu',
        'fallback_cb'    => '__return_empty_string',
      ]);
      ?>
    </nav>

    <button id="menu-toggle" class="burger" aria-expanded="false" aria-controls="site-nav" aria-label="<?php esc_attr_e('Ouvrir le menu','ozitheme'); ?>">
      <span></span><span></span><span></span>
    </button>
  </div>
</header>
