/* OZI Showcase — slider + sections full-screen + deep-link par PATH
   - URL propres: /showcase/<slug> (sans hash)
   - "Infos": sections plein écran, image de fond, bouton "Voir plus"
   - "Technique": 2 colonnes plein écran (Caractéristiques / Équipement)
   - "Avis": carrousel horizontal plein écran (sans rating)
   - "FAQ": plein écran
*/
(function () {
  const init = () => {
    const slidesEl  = document.getElementById("slides");
    const sliderEl  = document.getElementById("slider");
    const detailsEl = document.getElementById("details-card");
    const prev      = document.getElementById("prev");
    const next      = document.getElementById("next");
    const nav       = document.getElementById("nav-arrows");
    const discover  = document.getElementById("discover");

    if (!slidesEl || !detailsEl || !sliderEl) return;

    const products = Array.isArray(window.OZI_DATA?.products) ? window.OZI_DATA.products : [];
    const slides   = document.querySelectorAll(".slide");
    if (!products.length || !slides.length) {
      detailsEl.innerHTML = '<p style="padding:16px">Aucune remorque trouvée.</p>';
      return;
    }

    // réserve exactement la place du header (et de la barre admin s'il y en a)
    function updateSafeTop() {
      const admin = document.getElementById('wpadminbar');
      const header = document.getElementById('site-header');
      const adminH  = admin ? admin.offsetHeight : 0;
      const headerH = header ? header.getBoundingClientRect().height : 0;

      const safeTop = adminH + headerH;            // espace à réserver
      document.documentElement.style.setProperty('--safe-top', safeTop + 'px');

      // remonte un peu le bouton si l’espace est vraiment serré
      const captionShim = Math.max(24, Math.min(48, Math.round(safeTop * 0.25)));
      document.documentElement.style.setProperty('--caption-bottom', captionShim + 'px');
    }

    updateSafeTop();
    window.addEventListener('load', updateSafeTop);
    window.addEventListener('resize', updateSafeTop);

    /* ================= Path-based deep-link ================= */
    function normalizeBase(str) {
      try {
        // Accepte valeur absolue ou relative et en extrait le PATH
        const u = new URL(str, window.location.origin);
        let p = u.pathname || "/";
        if (!p.endsWith("/")) p += "/";
        return p;
      } catch {
        let p = String(str || "/");
        if (!p.startsWith("/")) p = "/" + p;
        if (!p.endsWith("/")) p += "/";
        return p;
      }
    }
    const basePath = normalizeBase(sliderEl.dataset.base || "/showcase/");
    const startSlug = (sliderEl.dataset.start || "").replace(/^\/+|\/+$/g, "");

    function slugFromPath() {
      // pathname attendu: /showcase/<slug> ou juste /showcase/
      const path = window.location.pathname;
      if (!path.startsWith(basePath)) return startSlug || products[0]?.slug || "";
      const rest = path.slice(basePath.length).replace(/^\/+|\/+$/g, "");
      return rest;
    }
    function indexFromURL() {
      const slug = slugFromPath();
      if (!slug) return 0;
      const i = products.findIndex(p => p.slug === slug);
      return i >= 0 ? i : 0;
    }
    function setURL(i, push=false) {
      const p = products[i]; if (!p) return;
      const href = basePath + encodeURIComponent(p.slug || String(i));
      if (push) history.pushState({ i }, '', href);
      else      history.replaceState({ i }, '', href);
    }

    /* ================= Rendering helpers ================= */
   
        function initInfosSlider(scope){
      const wrap  = scope.querySelector('.infos-full');
      if (!wrap) return;
      const track = wrap.querySelector('.infos-track');
      const slides = [...wrap.querySelectorAll('.info-slide')];
      const next  = wrap.querySelector('.info-next');
      if (!slides.length) return;

      let idx = 0;
      function setActive(){
        slides.forEach((s,i)=>s.classList.toggle('is-active', i===idx));
        track.style.transform = `translateX(-${idx * 100}%)`;
      }
      setActive();

      // Navigation au bouton uniquement
      next?.addEventListener('click', ()=>{
        idx = (idx + 1) % slides.length;
        setActive();
      });

      // Bloque le swipe horizontal / drag souris sur la piste
      const block = e => { 
        // on laisse le scroll VERTICAL passer (touch-action: pan-y gère déjà le tactile)
        // ici on neutralise un éventuel drag start
        if (e.type === 'mousedown') e.preventDefault();
      };
      track.addEventListener('mousedown', block);
      track.addEventListener('dragstart', e => e.preventDefault());
    }

    /* ================= Render details ================= */
    function renderDetails(i) {
      const p = products[i]; if (!p) return;

      // Infos — slider contrôlé par bouton
    const infos = Array.isArray(p.infos) ? p.infos : [];
    const infosHTML = infos.length ? `
      <section class="infos-full">
        <div class="infos-track">
          ${infos.map(s => `
            <article class="info-slide">
              <div class="info-left">
                ${s.title ? `<h3>${s.title}</h3>` : ''}
                ${s.text ? `<p>${s.text}</p>` : ''}
              </div>
              <div class="info-right">
                ${s.image ? `<img src="${s.image}" alt="">` : ''}
              </div>
            </article>
          `).join('')}
        </div>
        <button class="info-next" aria-label="Suivant" title="Suivant">❯</button>
      </section>
    ` : "";


      // --- Technique full-screen (2 colonnes)
      const car = Array.isArray(p.tech?.caracteristiques) ? p.tech.caracteristiques : [];
      const eqp = Array.isArray(p.tech?.equipements) ? p.tech.equipements : [];
      const techHTML = (car.length || eqp.length) ? `
        <section class="tech-full">
          <div class="tech-cols">
            <article class="tech-card">
              <h3>Caractéristiques</h3>
              <table>
                ${car.map(r=>`<tr><th>${r.label||''}</th><td>${r.value||''}</td></tr>`).join('')}
              </table>
            </article>
            <article class="tech-card">
              <h3>Équipement</h3>
              <table>
                ${eqp.map(r=>`<tr><th>${r.label||''}</th><td>${r.value||''}</td></tr>`).join('')}
              </table>
            </article>
          </div>
        </section>
      ` : "";

      // --- Avis (auto-slide + fade) ---
      const reviews = Array.isArray(p.reviews) ? p.reviews : [];
      const reviewsHTML = reviews.length ? `
        <section class="reviews-full">
          <h3 style="margin:0 0 14px;font-weight:800">Avis</h3>
          <div class="reviews-track">
            ${reviews.map(r => `
              <article class="review">
                <blockquote>${r.text || ''}</blockquote>
                <div class="author">— ${r.author || ''}</div>
              </article>
            `).join('')}
          </div>
        </section>
      ` : "";


      // --- FAQ full-screen
      const faq = Array.isArray(p.faq) ? p.faq : [];
      const faqHTML = faq.length ? `
        <section class="faq-full">
          <div class="faq-box">
            <h3>FAQ</h3>
            ${faq.map(f=>`
              <details>
                <summary>${f.q||''}</summary>
                <p style="margin-top:6px">${f.a||''}</p>
              </details>
            `).join('')}
          </div>
        </section>
      ` : "";

      // --- CTA
      const ctaHTML = p.buyLink ? `
        <p style="text-align:center">
          <a class="btn-buy" href="${p.buyLink}" target="_blank" rel="noopener">
            ${p.buyLabel || 'Acheter maintenant'}
          </a>
        </p>` : "";

      detailsEl.innerHTML = `
        ${infosHTML}
        ${techHTML}
        ${reviewsHTML}
        ${faqHTML}
        ${ctaHTML}
      `;
              initAutoReviews(detailsEl);
              initInfosSlider(detailsEl);


    }
    /* ========= Avis : autoplay + centrage permanent ========= */
function initAutoReviews(scope){
  const track = scope.querySelector('.reviews-track');
  if (!track) return;
  const cards = [...track.querySelectorAll('.review')];
  if (cards.length <= 1) return;

  // Mesure la largeur réelle d'une carte et centre le premier/dernier via padding
  function setPad(){
    const w = cards[0].getBoundingClientRect().width;
    track.style.setProperty('--review-w', w + 'px');
  }
  setPad();
  window.addEventListener('resize', () => { setPad(); center(idx, false); });

  // Met en avant la carte centrée
  const io = new IntersectionObserver((entries)=>{
    entries.forEach(e=>{
      e.target.classList.toggle('is-active', e.isIntersecting);
    });
  }, { root: track, threshold: 0.6 });
  cards.forEach(c => io.observe(c));

  let idx = 0, timer = null, busy = false, scrollDebounce = null;

  function center(i, smooth = true){
    i = (i + cards.length) % cards.length;
    const card = cards[i];
    const left = card.offsetLeft - (track.clientWidth - card.offsetWidth)/2;
    track.scrollTo({ left, behavior: smooth ? 'smooth' : 'auto' });
    idx = i;
  }

  function go(next){
    if (busy) return;
    busy = true;
    track.classList.add('is-fading');
    center(next, true);
    setTimeout(()=>{ track.classList.remove('is-fading'); busy = false; }, 650);
  }
  function start(){ if (!timer) timer = setInterval(()=>go(idx+1), 4500); }
  function stop(){  if (timer) { clearInterval(timer); timer = null; } }

  // pause sur interaction
  track.addEventListener('pointerenter', stop, {passive:true});
  track.addEventListener('pointerleave', start, {passive:true});
  track.addEventListener('touchstart', stop, {passive:true});
  track.addEventListener('touchend', start, {passive:true});
   track.addEventListener('scroll', () => {
    stop();
    if (scrollDebounce) clearTimeout(scrollDebounce);
    scrollDebounce = setTimeout(() => {
      const viewCenter = track.scrollLeft + track.clientWidth / 2;
      let best = 0, bestDist = Infinity;
      cards.forEach((c, i) => {
        const centerX = c.offsetLeft + c.offsetWidth / 2;
        const d = Math.abs(centerX - viewCenter);
        if (d < bestDist) { bestDist = d; best = i; }
      });
      center(best);
      start();
    }, 120);
  }, { passive:true });

  // Premier affichage centré + autoplay
  center(0, false);
  // premier run
  start();
}

    /* ================= Media sync ================= */
    function syncHeroMedia(activeIndex) {
      document.querySelectorAll('.slide').forEach((s, i) => {
        const vid = s.querySelector('video.hero-media');
        const ifr = s.querySelector('iframe.hero-media');

        if (i !== activeIndex) {
          if (vid) { try { vid.pause(); vid.currentTime = 0; } catch(e){} }
          if (ifr && ifr.src) { ifr.src = ''; }
          return;
        }
        if (vid) { vid.muted = true; vid.play().catch(()=>{}); }
        if (ifr && !ifr.src && ifr.dataset.src) { ifr.src = ifr.dataset.src; }
      });
    }

    /* ================= Navigation / swipe ================= */
    let index = 0, hideTimer;
    function showArrows(){ if(!nav) return; nav.classList.add('visible'); clearTimeout(hideTimer); hideTimer=setTimeout(()=>nav.classList.remove('visible'), 2000); }
    function go(n, push=false){
      const max = Math.min(slides.length, products.length);
      index = (n + max) % max;
      slidesEl.style.transform = `translateX(-${index*100}%)`;
      renderDetails(index);
      syncHeroMedia(index);
      showArrows();
      setURL(index, push);
    }

    prev?.addEventListener('click', ()=>go(index-1, true));
    next?.addEventListener('click', ()=>go(index+1, true));
    sliderEl.addEventListener('mousemove', showArrows);
    sliderEl.addEventListener('touchstart', showArrows, {passive:true});
    discover?.addEventListener('click', ()=>document.getElementById('content')?.scrollIntoView({behavior:'smooth'}));

    // Swipe
    let sx=null, sy=null, sliding=false;
    sliderEl.addEventListener('touchstart', e=>{ const t=e.touches[0]; sx=t.clientX; sy=t.clientY; sliding=true; }, {passive:true});
    sliderEl.addEventListener('touchmove', e=>{
      if(!sliding) return;
      const t=e.touches[0], dx=t.clientX-sx, dy=t.clientY-sy;
      if(Math.abs(dx)>24 && Math.abs(dx)>Math.abs(dy)){
        e.preventDefault();
        go(dx>0 ? index-1 : index+1, true);
        sliding=false;
      }
    }, {passive:false});
    sliderEl.addEventListener('touchend', ()=>sliding=false);

    // Historique
    window.addEventListener('popstate', ()=>{ const i=indexFromURL(); if(i!==index) go(i,false); });

    // Première vue
    go(indexFromURL(), false);
  };

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init);
  else init();
})();
